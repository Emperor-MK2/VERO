#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"; mkdir -p assets
python3 - <<'PY'
import json,os,subprocess
m=json.load(open('assets.json'))
for name,url in m.items():
    ext='.png' if name=='hero' else '.jpg'
    out=f'assets/{name}{ext}'
    print('downloading',name)
    subprocess.run(['curl','-fL','--retry','2','-o',out,url],check=True)
# replace the local paths while preserving data-fallback for offline fallback
p=open('index.html',encoding='utf8').read()
for name in m:
    ext='.png' if name=='hero' else '.jpg'
    p=p.replace(f'data-fallback="{m[name]}"',f'data-fallback="{m[name]}"')
open('index.html','w',encoding='utf8').write(p)
PY
# SVGs/icons can be added later from the narrower Figma nodes; raster assets above are the complete photo set used by this implementation.
